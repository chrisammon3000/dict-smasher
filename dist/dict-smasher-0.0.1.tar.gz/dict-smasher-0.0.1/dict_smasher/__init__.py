"""Utils package for vid-masher-tt."""

__author__ = """Gregory Lindsey"""
__email__ = 'gclindsey@gmail.com'
__version__ = '0.1.0'
